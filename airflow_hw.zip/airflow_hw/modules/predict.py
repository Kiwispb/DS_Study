# <YOUR_IMPORTS>
import os
import dill
import json
import pandas as pd

from datetime import datetime
from glob import glob


path = os.environ.get('PROJECT_PATH', '.')


def prediction(model):
    test_list = (glob(f'{path}/data/test/*'))
    car_id = []
    price_cat = []
    for item in test_list:
        with open(item) as fin:
            form = json.load(fin)
            df = pd.DataFrame.from_dict([form])
            car_id.append(form['id'])
            price_cat.append(model.predict(df)[0])
    dataframe = pd.DataFrame({'Test_id': car_id, 'Price_cat': price_cat})
    return dataframe


def predict():
    # <YOUR_CODE>
    file_name = max(glob(f'{path}/data/models/*'))
    with open(file_name, 'rb') as file:
        model = dill.load(file)
        df_pred = prediction(model)
        filename = f'{path}/data/predictions/pred_{datetime.now().strftime("%Y%m%d%H%M")}.csv'
        df_pred.to_csv(filename)



if __name__ == '__main__':
    predict()
